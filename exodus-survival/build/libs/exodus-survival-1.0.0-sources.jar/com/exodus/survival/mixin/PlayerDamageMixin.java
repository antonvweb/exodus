package com.exodus.survival.mixin;

import com.exodus.survival.systems.BodyPartDamageSystem;
import net.minecraft.class_1282;
import net.minecraft.class_1657;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Перехватываем весь урон игрока
 */
@Mixin(class_1657.class)
public class PlayerDamageMixin {

    @Inject(method = "hurt", at = @At("HEAD"), cancellable = true)
    private void onPlayerHurt(class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        class_1657 player = (class_1657)(Object)this;

        // Только на сервере
        if (player.method_37908().field_9236) {
            return;
        }

        // ОТМЕНЯЕМ весь ванильный урон
        cir.setReturnValue(false);

        // Применяем через нашу систему
        BodyPartDamageSystem.handleDamage((class_3222)player, source, amount);
    }
}