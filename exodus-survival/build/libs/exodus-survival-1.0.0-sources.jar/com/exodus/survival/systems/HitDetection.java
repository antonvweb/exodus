package com.exodus.survival.systems;

import com.exodus.core.api.player.BodyPart;
import java.util.Random;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1676;
import net.minecraft.class_243;
import net.minecraft.class_3222;

/**
 * Система определения места попадания
 * НОВАЯ ВЕРСИЯ - учитывает угол и направление атаки
 */
public class HitDetection {

    private static final Random RANDOM = new Random();

    /**
     * Определить место попадания
     */
    public static BodyPart detectHitLocation(class_3222 player, class_1282 source) {
        class_1297 sourceEntity = source.method_5529();

        if (sourceEntity == null) {
            return getRandomBodyPart(); // Случайная часть для неизвестного источника
        }

        // Снаряды (стрелы, трезубцы)
        if (source.method_5526() instanceof class_1676) {
            return detectProjectileHit(player, (class_1676) source.method_5526());
        }

        // Ближний бой (мобы, игроки)
        if (sourceEntity instanceof class_1309 attacker) {
            return detectMeleeHit(player, attacker);
        }

        return getRandomBodyPart();
    }

    /**
     * Определить попадание снаряда (ТОЧНОЕ)
     */
    private static BodyPart detectProjectileHit(class_3222 player, class_1676 projectile) {
        class_243 projectilePos = projectile.method_19538();
        class_243 playerPos = player.method_19538();

        double playerHeight = player.method_17682();
        double relativeHeight = (projectilePos.field_1351 - playerPos.field_1351) / playerHeight;

        // Снаряд летит точно - определяем по высоте
        if (relativeHeight >= 0.85) {
            return BodyPart.HEAD; // Попадание в голову
        } else if (relativeHeight >= 0.35) {
            // Торс или руки - зависит от горизонтального смещения
            double horizontalOffset = Math.abs(projectilePos.field_1352 - playerPos.field_1352) +
                    Math.abs(projectilePos.field_1350 - playerPos.field_1350);

            if (horizontalOffset > 0.3) {
                // Попадание сбоку - скорее всего рука
                return RANDOM.nextBoolean() ? BodyPart.LEFT_ARM : BodyPart.RIGHT_ARM;
            } else {
                // Попадание в центр - торс
                return BodyPart.TORSO;
            }
        } else {
            // Низкое попадание - ноги
            return RANDOM.nextBoolean() ? BodyPart.LEFT_LEG : BodyPart.RIGHT_LEG;
        }
    }

    /**
     * Определить попадание в ближнем бою (ВЕРОЯТНОСТНОЕ)
     */
    private static BodyPart detectMeleeHit(class_3222 player, class_1309 attacker) {
        // 1. Определяем направление атаки
        AttackDirection direction = getAttackDirection(player, attacker);

        // 2. Определяем вертикальный угол
        AttackAngle angle = getAttackAngle(player, attacker);

        // 3. Выбираем часть тела на основе направления и угла
        return selectBodyPartByProbability(direction, angle);
    }

    /**
     * Направление атаки (спереди/сзади/сбоку)
     */
    private enum AttackDirection {
        FRONT,  // Спереди (±60°)
        BACK,   // Сзади (±60° от 180°)
        LEFT,   // Слева
        RIGHT   // Справа
    }

    /**
     * Угол атаки (сверху/нормально/снизу)
     */
    private enum AttackAngle {
        FROM_ABOVE,   // Атака сверху (атакующий выше на 1+ блок)
        NORMAL,       // Нормальная атака
        FROM_BELOW    // Атака снизу (атакующий ниже на 0.5+ блок)
    }

    /**
     * Определить направление атаки
     */
    private static AttackDirection getAttackDirection(class_3222 player, class_1309 attacker) {
        class_243 toAttacker = attacker.method_19538().method_1020(player.method_19538()).method_1029();
        class_243 playerLook = player.method_5720();

        // Угол между взглядом игрока и направлением на атакующего
        double dotProduct = playerLook.field_1352 * toAttacker.field_1352 + playerLook.field_1350 * toAttacker.field_1350;
        double angle = Math.acos(dotProduct);

        // Определяем с какой стороны атакующий
        double crossProduct = playerLook.field_1352 * toAttacker.field_1350 - playerLook.field_1350 * toAttacker.field_1352;

        if (Math.abs(angle) < Math.PI / 3) {
            return AttackDirection.FRONT; // Спереди (±60°)
        } else if (Math.abs(angle) > 2 * Math.PI / 3) {
            return AttackDirection.BACK; // Сзади
        } else if (crossProduct > 0) {
            return AttackDirection.LEFT; // Слева
        } else {
            return AttackDirection.RIGHT; // Справа
        }
    }

    /**
     * Определить вертикальный угол атаки
     */
    private static AttackAngle getAttackAngle(class_3222 player, class_1309 attacker) {
        double heightDifference = attacker.method_23320() - player.method_23320();

        if (heightDifference > 1.0) {
            return AttackAngle.FROM_ABOVE; // Атакующий сильно выше
        } else if (heightDifference < -0.5) {
            return AttackAngle.FROM_BELOW; // Атакующий ниже
        } else {
            return AttackAngle.NORMAL; // Примерно на одном уровне
        }
    }

    /**
     * Выбрать часть тела на основе вероятностей
     */
    private static BodyPart selectBodyPartByProbability(AttackDirection direction, AttackAngle angle) {
        // Атака сверху - приоритет голова
        if (angle == AttackAngle.FROM_ABOVE) {
            float roll = RANDOM.nextFloat() * 100;
            if (roll < 60) return BodyPart.HEAD;
            if (roll < 90) return BodyPart.TORSO;
            return RANDOM.nextBoolean() ? BodyPart.LEFT_ARM : BodyPart.RIGHT_ARM;
        }

        // Атака снизу - приоритет ноги
        if (angle == AttackAngle.FROM_BELOW) {
            float roll = RANDOM.nextFloat() * 100;
            if (roll < 60) return RANDOM.nextBoolean() ? BodyPart.LEFT_LEG : BodyPart.RIGHT_LEG;
            if (roll < 90) return BodyPart.TORSO;
            if (roll < 95) return RANDOM.nextBoolean() ? BodyPart.LEFT_ARM : BodyPart.RIGHT_ARM;
            return BodyPart.HEAD;
        }

        // Нормальный угол - зависит от направления
        return switch (direction) {
            case FRONT -> selectFrontAttack();
            case BACK -> selectBackAttack();
            case LEFT -> selectSideAttack(BodyPart.LEFT_ARM, BodyPart.LEFT_LEG);
            case RIGHT -> selectSideAttack(BodyPart.RIGHT_ARM, BodyPart.RIGHT_LEG);
        };
    }

    /**
     * Атака спереди
     */
    private static BodyPart selectFrontAttack() {
        float roll = RANDOM.nextFloat() * 100;

        if (roll < 15) {
            return BodyPart.HEAD; // 15%
        } else if (roll < 65) {
            return BodyPart.TORSO; // 50%
        } else if (roll < 90) {
            // 25% - руки (случайная)
            return RANDOM.nextBoolean() ? BodyPart.LEFT_ARM : BodyPart.RIGHT_ARM;
        } else {
            // 10% - ноги (случайная)
            return RANDOM.nextBoolean() ? BodyPart.LEFT_LEG : BodyPart.RIGHT_LEG;
        }
    }

    /**
     * Атака сзади
     */
    private static BodyPart selectBackAttack() {
        float roll = RANDOM.nextFloat() * 100;

        if (roll < 5) {
            return BodyPart.HEAD; // 5%
        } else if (roll < 75) {
            return BodyPart.TORSO; // 70%
        } else if (roll < 90) {
            // 15% - руки
            return RANDOM.nextBoolean() ? BodyPart.LEFT_ARM : BodyPart.RIGHT_ARM;
        } else {
            // 10% - ноги
            return RANDOM.nextBoolean() ? BodyPart.LEFT_LEG : BodyPart.RIGHT_LEG;
        }
    }

    /**
     * Атака сбоку
     */
    private static BodyPart selectSideAttack(BodyPart arm, BodyPart leg) {
        float roll = RANDOM.nextFloat() * 100;

        if (roll < 10) {
            return BodyPart.HEAD; // 10%
        } else if (roll < 50) {
            return BodyPart.TORSO; // 40%
        } else if (roll < 90) {
            return arm; // 40% - рука со стороны атаки
        } else {
            return leg; // 10% - нога со стороны атаки
        }
    }

    /**
     * Случайная часть тела (для неизвестных источников)
     */
    private static BodyPart getRandomBodyPart() {
        BodyPart[] parts = BodyPart.values();
        return parts[RANDOM.nextInt(parts.length)];
    }
}