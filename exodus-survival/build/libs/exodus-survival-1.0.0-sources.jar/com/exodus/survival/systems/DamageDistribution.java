package com.exodus.survival.systems;

import com.exodus.core.api.player.BodyPart;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1282;
import net.minecraft.class_3222;
import net.minecraft.class_8111;

public class DamageDistribution {

    public static Map<BodyPart, Float> getDamageDistribution(class_3222 player, class_1282 source, float amount) {

        // === МГНОВЕННАЯ СМЕРТЬ ===
        // ИСПРАВЛЕНО: OUT_OF_WORLD → FELL_OUT_OF_WORLD
        if (source.method_49708(class_8111.field_42347) || source.method_49708(class_8111.field_42348)) {
            return createInstantDeath();
        }

        // === ПАДЕНИЕ ===
        if (source.method_49708(class_8111.field_42345) || source.method_49708(class_8111.field_42346)) {
            return createFallDamage(amount);
        }

        // === УТОПЛЕНИЕ/УДУШЬЕ ===
        if (source.method_49708(class_8111.field_42340)) {
            return createSuffocationDamage(amount);
        }

        // === ОГОНЬ/ЛАВА ===
        if (source.method_49708(class_8111.field_42335) || source.method_49708(class_8111.field_42337) ||
                source.method_49708(class_8111.field_42338) || source.method_49708(class_8111.field_42339)) {
            return createFireDamage(amount);
        }

        // === ВЗРЫВ ===
        if (source.method_49708(class_8111.field_42331) || source.method_49708(class_8111.field_42332)) {
            return createExplosionDamage(amount);
        }

        // === МОЛНИЯ ===
        if (source.method_49708(class_8111.field_42336)) {
            return createLightningDamage(amount);
        }

        // === ИССУШЕНИЕ/ЯД (DoT) ===
        if (source.method_49708(class_8111.field_42350) || source.method_49708(class_8111.field_42349)) {
            return createPoisonDamage(amount);
        }

        // === ЗАМЕРЗАНИЕ ===
        if (source.method_49708(class_8111.field_42354)) {
            return createFreezeDamage(amount);
        }

        // === КАКТУС/ШИПЫ ===
        if (source.method_49708(class_8111.field_42344) || source.method_49708(class_8111.field_42353)) {
            return createPiercingDamage(amount);
        }

        // === ПАДАЮЩИЕ БЛОКИ ===
        // ИСПРАВЛЕНО: убрали ANVIL и STALAGMITE (их нет в DamageTypes)
        if (source.method_49708(class_8111.field_42356) || source.method_49708(class_8111.field_42358)) {
            return createCrushingDamage(amount);
        }

        // === АТАКИ (меч, стрела, моб) ===
        return null;
    }

    // === ВСЕ МЕТОДЫ createXXXDamage остаются БЕЗ ИЗМЕНЕНИЙ ===

    private static Map<BodyPart, Float> createInstantDeath() {
        Map<BodyPart, Float> damage = new HashMap<>();
        for (BodyPart part : BodyPart.values()) {
            damage.put(part, 9999f);
        }
        return damage;
    }

    private static Map<BodyPart, Float> createFallDamage(float amount) {
        Map<BodyPart, Float> damage = new HashMap<>();
        damage.put(BodyPart.LEFT_LEG, amount * 0.5f);
        damage.put(BodyPart.RIGHT_LEG, amount * 0.5f);
        return damage;
    }

    private static Map<BodyPart, Float> createSuffocationDamage(float amount) {
        Map<BodyPart, Float> damage = new HashMap<>();
        damage.put(BodyPart.HEAD, amount * 0.7f);
        damage.put(BodyPart.TORSO, amount * 0.3f);
        return damage;
    }

    private static Map<BodyPart, Float> createStarvationDamage(float amount) {
        Map<BodyPart, Float> damage = new HashMap<>();
        damage.put(BodyPart.TORSO, amount);
        return damage;
    }

    private static Map<BodyPart, Float> createFireDamage(float amount) {
        Map<BodyPart, Float> damage = new HashMap<>();
        float perPart = amount / 6f;
        for (BodyPart part : BodyPart.values()) {
            damage.put(part, perPart);
        }
        return damage;
    }

    private static Map<BodyPart, Float> createExplosionDamage(float amount) {
        Map<BodyPart, Float> damage = new HashMap<>();
        damage.put(BodyPart.HEAD, amount * 0.1f);
        damage.put(BodyPart.TORSO, amount * 0.3f);
        damage.put(BodyPart.LEFT_ARM, amount * 0.15f);
        damage.put(BodyPart.RIGHT_ARM, amount * 0.15f);
        damage.put(BodyPart.LEFT_LEG, amount * 0.15f);
        damage.put(BodyPart.RIGHT_LEG, amount * 0.15f);
        return damage;
    }

    private static Map<BodyPart, Float> createLightningDamage(float amount) {
        Map<BodyPart, Float> damage = new HashMap<>();
        for (BodyPart part : BodyPart.values()) {
            damage.put(part, amount * 1.5f / 6f);
        }
        return damage;
    }

    private static Map<BodyPart, Float> createPoisonDamage(float amount) {
        Map<BodyPart, Float> damage = new HashMap<>();
        float perPart = amount / 6f;
        for (BodyPart part : BodyPart.values()) {
            damage.put(part, perPart);
        }
        return damage;
    }

    private static Map<BodyPart, Float> createFreezeDamage(float amount) {
        Map<BodyPart, Float> damage = new HashMap<>();
        damage.put(BodyPart.LEFT_ARM, amount * 0.25f);
        damage.put(BodyPart.RIGHT_ARM, amount * 0.25f);
        damage.put(BodyPart.LEFT_LEG, amount * 0.25f);
        damage.put(BodyPart.RIGHT_LEG, amount * 0.25f);
        return damage;
    }

    private static Map<BodyPart, Float> createPiercingDamage(float amount) {
        Map<BodyPart, Float> damage = new HashMap<>();
        BodyPart[] possibleParts = {BodyPart.TORSO, BodyPart.LEFT_LEG, BodyPart.RIGHT_LEG};
        BodyPart hitPart = possibleParts[(int)(Math.random() * possibleParts.length)];
        damage.put(hitPart, amount);
        return damage;
    }

    private static Map<BodyPart, Float> createCrushingDamage(float amount) {
        Map<BodyPart, Float> damage = new HashMap<>();
        damage.put(BodyPart.HEAD, amount * 0.5f);
        damage.put(BodyPart.LEFT_ARM, amount * 0.25f);
        damage.put(BodyPart.RIGHT_ARM, amount * 0.25f);
        return damage;
    }
}