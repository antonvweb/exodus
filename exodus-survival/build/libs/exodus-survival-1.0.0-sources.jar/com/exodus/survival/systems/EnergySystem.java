package com.exodus.survival.systems;

import com.exodus.core.ExodusCoreAPI;
import com.exodus.core.api.stats.IPlayerStat;
import com.exodus.core.api.stats.VitalType;
import java.util.Optional;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_3222;

/**
 * Система энергии
 * Управляет усталостью и влиянием на скорость игрока
 */
public class EnergySystem {

    private static final int EFFECT_CHECK_INTERVAL = 20; // Проверяем раз в секунду
    private static int tickCounter = 0;

    public static void tick(class_3222 player) {
        tickCounter++;

        if (tickCounter >= EFFECT_CHECK_INTERVAL) {
            tickCounter = 0;

            applyEnergyEffects(player);
            checkEnergyReplenishment(player);
        }

        // Увеличенный расход энергии при активных действиях
        checkActiveEnergyConsumption(player);
    }

    /**
     * Применить эффекты от усталости
     */
    private static void applyEnergyEffects(class_3222 player) {
        Optional<IPlayerStat> energyOpt = ExodusCoreAPI.getVital(player, VitalType.ENERGY);

        if (energyOpt.isEmpty()) {
            return;
        }

        IPlayerStat energy = energyOpt.get();
        float energyPercent = energy.getPercentage();

        // Критическая усталость (0-10%)
        if (energyPercent <= 0.1f) {
            // Сильное замедление + слабость + тошнота
            player.method_6092(new class_1293(class_1294.field_5909, 60, 3, false, false));
            player.method_6092(new class_1293(class_1294.field_5911, 60, 2, false, false));
            player.method_6092(new class_1293(class_1294.field_5901, 60, 2, false, false));
            player.method_6092(new class_1293(class_1294.field_5916, 40, 0, false, false));
        }
        // Сильная усталость (10-25%)
        else if (energyPercent <= 0.25f) {
            // Замедление + слабость
            player.method_6092(new class_1293(class_1294.field_5909, 60, 2, false, false));
            player.method_6092(new class_1293(class_1294.field_5911, 60, 1, false, false));
            player.method_6092(new class_1293(class_1294.field_5901, 60, 1, false, false));
        }
        // Средняя усталость (25-50%)
        else if (energyPercent <= 0.5f) {
            // Легкое замедление
            player.method_6092(new class_1293(class_1294.field_5909, 60, 1, false, false));
            player.method_6092(new class_1293(class_1294.field_5901, 60, 0, false, false));
        }
        // Легкая усталость (50-75%)
        else if (energyPercent <= 0.75f) {
            // Минимальное замедление копания
            player.method_6092(new class_1293(class_1294.field_5901, 60, 0, false, false));
        }
        // Нормальная энергия (75-100%) - без эффектов
    }

    /**
     * Проверить восстановление энергии
     */
    private static void checkEnergyReplenishment(class_3222 player) {
        Optional<IPlayerStat> energyOpt = ExodusCoreAPI.getVital(player, VitalType.ENERGY);

        if (energyOpt.isEmpty()) {
            return;
        }

        IPlayerStat energy = energyOpt.get();

        // Восстановление энергии когда игрок стоит на месте
        if (!player.method_5624() &&
                !player.method_5681() &&
                player.method_18798().method_37268() < 0.001) {

            // Медленное восстановление энергии
            float restoreRate = 0.5f; // 0.5 единицы в секунду
            float newValue = Math.min(energy.getCurrent() + restoreRate, energy.getMax());
            energy.setCurrent(newValue);
        }

        // Ускоренное восстановление если игрок не двигается и присел
        if (player.method_18276() &&
                player.method_18798().method_37268() < 0.001) {

            float fastRestoreRate = 1.5f; // 1.5 единицы в секунду
            float newValue = Math.min(energy.getCurrent() + fastRestoreRate, energy.getMax());
            energy.setCurrent(newValue);
        }
    }

    /**
     * Проверить увеличенный расход энергии при активности
     */
    private static void checkActiveEnergyConsumption(class_3222 player) {
        Optional<IPlayerStat> energyOpt = ExodusCoreAPI.getVital(player, VitalType.ENERGY);

        if (energyOpt.isEmpty()) {
            return;
        }

        IPlayerStat energy = energyOpt.get();

        // Увеличенный расход при спринте (каждый тик)
        if (player.method_5624()) {
            energy.add(-0.05f); // Дополнительные -0.05 за тик = -1 в секунду
        }

        // Увеличенный расход при плавании
        if (player.method_5681()) {
            energy.add(-0.03f); // -0.03 за тик = -0.6 в секунду
        }

        // Увеличенный расход при прыжках (проверяем что игрок в воздухе и движется вверх)
        if (!player.method_24828() && player.method_18798().field_1351 > 0) {
            energy.add(-0.01f); // -0.01 за тик полета = -0.2 в секунду
        }

        // Не даем энергии уйти в минус
        if (energy.getCurrent() < 0) {
            energy.setCurrent(0);
        }
    }

    /**
     * Восстановить энергию (от еды/отдыха)
     */
    public static void replenishEnergy(class_3222 player, float amount) {
        ExodusCoreAPI.getVital(player, VitalType.ENERGY).ifPresent(energy -> {
            float newValue = Math.min(energy.getCurrent() + amount, energy.getMax());
            energy.setCurrent(newValue);
        });
    }

    /**
     * Проверить истощен ли игрок
     */
    public static boolean isExhausted(class_3222 player) {
        return ExodusCoreAPI.getVital(player, VitalType.ENERGY)
                .map(energy -> energy.getPercentage() <= 0.25f)
                .orElse(false);
    }
}