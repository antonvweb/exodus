package com.exodus.survival.systems;

import com.exodus.core.ExodusCoreAPI;
import com.exodus.core.api.player.BodyPart;
import com.exodus.core.api.stats.IPlayerStat;
import com.exodus.core.api.stats.VitalType;
import java.util.Optional;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_3222;

/**
 * Система голода и жажды
 * Управляет негативными эффектами от недостатка еды и воды
 */
public class HungerThirstSystem {

    private static final int EFFECT_CHECK_INTERVAL = 20; // Проверяем раз в секунду
    private static int tickCounter = 0;

    public static void tick(class_3222 player) {
        tickCounter++;

        if (tickCounter >= EFFECT_CHECK_INTERVAL) {
            tickCounter = 0;

            applyHungerEffects(player);
            applyThirstEffects(player);
        }
    }

    /**
     * Применить эффекты от голода
     */
    private static void applyHungerEffects(class_3222 player) {
        Optional<IPlayerStat> hungerOpt = ExodusCoreAPI.getVital(player, VitalType.HUNGER);

        if (hungerOpt.isEmpty()) {
            return;
        }

        IPlayerStat hunger = hungerOpt.get();
        float hungerPercent = hunger.getPercentage();

        // Критический голод (0-25%)
        if (hungerPercent <= 0.25f) {
            // Слабость III + урон
            player.method_6092(new class_1293(class_1294.field_5911, 60, 2, false, false));
            player.method_6092(new class_1293(class_1294.field_5909, 60, 1, false, false));

            // НОВОЕ: Наносим урон в торс если голод = 0
            if (hungerPercent == 0) {
                ExodusCoreAPI.damageBodyPart(player, BodyPart.TORSO, 0.5f);

                // Синхронизируем ванильное HP
                float totalHP = ExodusCoreAPI.getTotalHP(player);
                player.method_6033(Math.max(0.5f, totalHP));
            }
        }
        // Средний голод (25-50%)
        else if (hungerPercent <= 0.5f) {
            // Слабость I
            player.method_6092(new class_1293(class_1294.field_5911, 60, 0, false, false));
        }
        // Легкий голод (50-75%)
        else if (hungerPercent <= 0.75f) {
            // Замедление регенерации (визуальный индикатор)
            // Реальное влияние будет в системе здоровья
        }
        // Нормальный голод (75-100%) - без эффектов
    }

    /**
     * Применить эффекты от жажды
     */
    private static void applyThirstEffects(class_3222 player) {
        Optional<IPlayerStat> thirstOpt = ExodusCoreAPI.getVital(player, VitalType.THIRST);

        if (thirstOpt.isEmpty()) {
            return;
        }

        IPlayerStat thirst = thirstOpt.get();
        float thirstPercent = thirst.getPercentage();

        // Критическая жажда (0-25%)
        if (thirstPercent <= 0.25f) {
            // Тошнота + усталость + медлительность
            player.method_6092(new class_1293(class_1294.field_5916, 60, 0, false, false));
            player.method_6092(new class_1293(class_1294.field_5909, 60, 2, false, false));
            player.method_6092(new class_1293(class_1294.field_5901, 60, 1, false, false));

            // Ускоренная потеря энергии
            ExodusCoreAPI.getVital(player, VitalType.ENERGY).ifPresent(energy -> {
                energy.add(-0.5f); // Дополнительная потеря энергии
            });
        }
        // Сильная жажда (25-50%)
        else if (thirstPercent <= 0.5f) {
            // Замедление + усталость
            player.method_6092(new class_1293(class_1294.field_5909, 60, 0, false, false));
            player.method_6092(new class_1293(class_1294.field_5901, 60, 0, false, false));
        }
        // Средняя жажда (50-75%)
        else if (thirstPercent <= 0.75f) {
            // Легкое замедление копания
            player.method_6092(new class_1293(class_1294.field_5901, 60, 0, false, false));
        }
        // Нормальная жажда (75-100%) - без эффектов
    }

    /**
     * Восстановить голод (от еды)
     */
    public static void replenishHunger(class_3222 player, float amount) {
        ExodusCoreAPI.getVital(player, VitalType.HUNGER).ifPresent(hunger -> {
            float newValue = Math.min(hunger.getCurrent() + amount, hunger.getMax());
            hunger.setCurrent(newValue);
        });
    }

    /**
     * Восстановить жажду (от питья)
     */
    public static void replenishThirst(class_3222 player, float amount) {
        ExodusCoreAPI.getVital(player, VitalType.THIRST).ifPresent(thirst -> {
            float newValue = Math.min(thirst.getCurrent() + amount, thirst.getMax());
            thirst.setCurrent(newValue);
        });
    }

    /**
     * Проверить голоден ли игрок
     */
    public static boolean isStarving(class_3222 player) {
        return ExodusCoreAPI.getVital(player, VitalType.HUNGER)
                .map(hunger -> hunger.getPercentage() <= 0.25f)
                .orElse(false);
    }

    /**
     * Проверить испытывает ли игрок жажду
     */
    public static boolean isDehydrated(class_3222 player) {
        return ExodusCoreAPI.getVital(player, VitalType.THIRST)
                .map(thirst -> thirst.getPercentage() <= 0.25f)
                .orElse(false);
    }
}