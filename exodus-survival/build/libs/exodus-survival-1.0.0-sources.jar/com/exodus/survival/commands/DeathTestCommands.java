package com.exodus.survival.commands;

import com.exodus.core.ExodusCoreAPI;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.FloatArgumentType;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class DeathTestCommands {

    public static void register(CommandDispatcher<class_2168> dispatcher) {

        // /setblood <процент>
        dispatcher.register(class_2170.method_9247("setblood")
                .then(class_2170.method_9244("percent", FloatArgumentType.floatArg(0, 100))
                        .executes(context -> {
                            class_3222 player = context.getSource().method_9207();
                            float percent = FloatArgumentType.getFloat(context, "percent");

                            ExodusCoreAPI.setBloodLevel(player, percent);
                            player.method_43496(class_2561.method_43470("Уровень крови: " + percent + "%"));

                            return 1;
                        })
                )
        );

        // /settemp <градусы>
        dispatcher.register(class_2170.method_9247("settemp")
                .then(class_2170.method_9244("celsius", FloatArgumentType.floatArg(20, 45))
                        .executes(context -> {
                            class_3222 player = context.getSource().method_9207();
                            float temp = FloatArgumentType.getFloat(context, "celsius");

                            ExodusCoreAPI.setBodyTemperature(player, temp);
                            player.method_43496(class_2561.method_43470("Температура тела: " + temp + "°C"));

                            return 1;
                        })
                )
        );
    }
}