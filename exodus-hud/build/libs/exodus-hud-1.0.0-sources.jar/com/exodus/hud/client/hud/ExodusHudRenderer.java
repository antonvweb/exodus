package com.exodus.hud.client.hud;

import com.exodus.core.ExodusCoreAPI;
import com.exodus.core.api.stats.IPlayerStat;
import com.exodus.core.api.stats.IStatsProvider;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.List;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class ExodusHudRenderer {

    private final class_310 minecraft;
    private static final class_2960 CROSSHAIR_TEXTURE = new class_2960("exodus-hud", "textures/gui/crosshair.png");
    private final BodyPartRenderer bodyPartRenderer; // ← ДОБАВЬ ЭТО

    public ExodusHudRenderer(class_310 minecraft) {
        this.minecraft = minecraft;
        this.bodyPartRenderer = new BodyPartRenderer(minecraft); // ← ДОБАВЬ ЭТО
    }

    public void render(class_332 guiGraphics, float tickDelta) {
        if (minecraft.field_1690.field_1842) {
            return;
        }

        int screenWidth = guiGraphics.method_51421();
        int screenHeight = guiGraphics.method_51443();

        renderCrosshair(guiGraphics, screenWidth, screenHeight);
        renderHotbar(guiGraphics, screenWidth, screenHeight, tickDelta);

        // ПОКАЗЫВАЕМ ЧАСТИ ТЕЛА (левый верхний угол)
        renderBodyParts(guiGraphics, screenWidth, screenHeight);

        // ПОКАЗЫВАЕМ КИСЛОРОД/ГОЛОД/ЖАЖДУ (правый верхний угол)
        renderPlayerStats(guiGraphics, screenWidth, screenHeight);
    }

    /**
     * Отрисовка частей тела персонажа
     */
    private void renderBodyParts(class_332 guiGraphics, int screenWidth, int screenHeight) {
        if (minecraft.field_1724 == null) {
            return;
        }

        bodyPartRenderer.render(guiGraphics, minecraft.field_1724, screenWidth, screenHeight);
    }

    private void renderCrosshair(class_332 guiGraphics, int screenWidth, int screenHeight) {
        if (!minecraft.field_1690.method_31044().method_31034()) {
            return;
        }

        RenderSystem.enableBlend();

        int centerX = screenWidth / 2;
        int centerY = screenHeight / 2;
        int crosshairSize = 8;
        int thickness = 2;
        int gap = 2;
        int color = 0xFFFFFFFF;

        guiGraphics.method_25294(centerX - crosshairSize - gap, centerY - thickness/2, centerX - gap, centerY + thickness/2, color);
        guiGraphics.method_25294(centerX + gap, centerY - thickness/2, centerX + crosshairSize + gap, centerY + thickness/2, color);
        guiGraphics.method_25294(centerX - thickness/2, centerY - crosshairSize - gap, centerX + thickness/2, centerY - gap, color);
        guiGraphics.method_25294(centerX - thickness/2, centerY + gap, centerX + thickness/2, centerY + crosshairSize + gap, color);

        RenderSystem.disableBlend();
    }

    private void renderHotbar(class_332 guiGraphics, int screenWidth, int screenHeight, float partialTick) {
        if (minecraft.field_1724 == null) {
            return;
        }

        RenderSystem.enableBlend();

        class_1661 inventory = minecraft.field_1724.method_31548();

        int baseSlotSize = 24;
        int mainHandSize = (int)(baseSlotSize * 1.7);
        int slotPadding = 4;
        int margin = 10;

        int startX = margin;
        int startY = screenHeight - margin;

        int mainHandX = startX;
        int mainHandY = startY - mainHandSize - baseSlotSize - slotPadding;

        guiGraphics.method_25294(mainHandX, mainHandY, mainHandX + mainHandSize, mainHandY + mainHandSize, 0x80000000);
        drawSlotBorder(guiGraphics, mainHandX, mainHandY, mainHandSize, 0xFF00FFFF, 2);

        class_1799 mainHandItem = inventory.method_7391();
        if (!mainHandItem.method_7960()) {
            int itemX = mainHandX + (mainHandSize - 16) / 2;
            int itemY = mainHandY + (mainHandSize - 16) / 2;
            guiGraphics.method_51427(mainHandItem, itemX, itemY);
            guiGraphics.method_51431(minecraft.field_1772, mainHandItem, itemX, itemY);
        }

        int toolSlotY = startY - baseSlotSize;
        int toolSlotX = startX;

        guiGraphics.method_25294(toolSlotX, toolSlotY, toolSlotX + baseSlotSize, toolSlotY + baseSlotSize, 0x80555555);
        drawSlotBorder(guiGraphics, toolSlotX, toolSlotY, baseSlotSize, 0xFFFFFFFF, 1);

        int selectedSlot = inventory.field_7545 + 1;
        String slotNumber = String.valueOf(selectedSlot);
        guiGraphics.method_51433(minecraft.field_1772, slotNumber, toolSlotX + 2, toolSlotY + 2, 0xFFFFFFFF, true);

        class_1799 toolItem = inventory.method_7391();
        if (!toolItem.method_7960()) {
            guiGraphics.method_51427(toolItem, toolSlotX + 4, toolSlotY + 4);
            guiGraphics.method_51431(minecraft.field_1772, toolItem, toolSlotX + 4, toolSlotY + 4);
        }

        int offhandX = toolSlotX + baseSlotSize + slotPadding;
        int offhandY = toolSlotY;

        guiGraphics.method_25294(offhandX, offhandY, offhandX + baseSlotSize, offhandY + baseSlotSize, 0x80000000);
        drawSlotBorder(guiGraphics, offhandX, offhandY, baseSlotSize, 0xFF00FF00, 1);

        class_1799 offhandItem = inventory.field_7544.get(0);
        if (!offhandItem.method_7960()) {
            guiGraphics.method_51427(offhandItem, offhandX + 4, offhandY + 4);
            guiGraphics.method_51431(minecraft.field_1772, offhandItem, offhandX + 4, offhandY + 4);
        }

        RenderSystem.disableBlend();
    }

    private void drawSlotBorder(class_332 guiGraphics, int x, int y, int size, int color, int thickness) {
        guiGraphics.method_25294(x, y, x + size, y + thickness, color);
        guiGraphics.method_25294(x, y + size - thickness, x + size, y + size, color);
        guiGraphics.method_25294(x, y, x + thickness, y + size, color);
        guiGraphics.method_25294(x + size - thickness, y, x + size, y + size, color);
    }

    /**
     * Отрисовка статов игрока через Core API
     */
    private void renderPlayerStats(class_332 guiGraphics, int screenWidth, int screenHeight) {
        if (minecraft.field_1724 == null) {
            return;
        }

        RenderSystem.enableBlend();

        IStatsProvider statsProvider = ExodusCoreAPI.getStatsProvider();
        List<IPlayerStat> stats = statsProvider.getStats(minecraft.field_1724);

        if (stats.isEmpty()) {
            RenderSystem.disableBlend();
            return;
        }

        // НОВАЯ ПОЗИЦИЯ: Правый верхний угол (чтобы не перекрывать части тела)
        int statsX = screenWidth - 120; // 120 пикселей от правого края
        int statsY = 10;
        int barWidth = 100;
        int barHeight = 8;
        int barSpacing = 12;

        int currentY = statsY;

        for (IPlayerStat stat : stats) {
            drawStatBar(
                    guiGraphics,
                    statsX,
                    currentY,
                    barWidth,
                    barHeight,
                    stat.getCurrent(),
                    stat.getMax(),
                    stat.getColor(),
                    darkenColor(stat.getColor()),
                    stat.getDisplayName()
            );
            currentY += barSpacing;
        }

        RenderSystem.disableBlend();
    }

    private void drawStatBar(class_332 guiGraphics, int x, int y, int width, int height,
                             float current, float max, int fillColor, int bgColor, String label) {
        // Фон
        guiGraphics.method_25294(x, y, x + width, y + height, bgColor);

        // Заполнение
        int fillWidth = (int)((current / max) * width);
        guiGraphics.method_25294(x, y, x + fillWidth, y + height, fillColor);

        // Рамка
        guiGraphics.method_25294(x, y, x + width, y + 1, 0xFFFFFFFF);
        guiGraphics.method_25294(x, y + height - 1, x + width, y + height, 0xFFFFFFFF);
        guiGraphics.method_25294(x, y, x + 1, y + height, 0xFFFFFFFF);
        guiGraphics.method_25294(x + width - 1, y, x + width, y + height, 0xFFFFFFFF);

        // Текст (название и значение)
        String text = label + ": " + (int)current + "/" + (int)max;
        guiGraphics.method_51433(minecraft.field_1772, text, x + 2, y - 8, 0xFFFFFFFF, true);
    }

    private int darkenColor(int color) {
        int alpha = (color >> 24) & 0xFF;
        int red = ((color >> 16) & 0xFF) / 3;
        int green = ((color >> 8) & 0xFF) / 3;
        int blue = (color & 0xFF) / 3;

        return (alpha << 24) | (red << 16) | (green << 8) | blue;
    }
}