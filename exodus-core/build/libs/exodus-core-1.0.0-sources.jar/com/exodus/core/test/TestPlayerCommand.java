package com.exodus.core.test;

import com.exodus.core.ExodusCoreAPI;
import com.exodus.core.api.player.BodyPart;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class TestPlayerCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
                class_2170.method_9247("testplayer")
                        .executes(TestPlayerCommand::execute)
        );

        dispatcher.register(
                class_2170.method_9247("damageleg")
                        .executes(TestPlayerCommand::damageLeg)
        );

        dispatcher.register(
                class_2170.method_9247("healleg")
                        .executes(TestPlayerCommand::healLeg)
        );

        dispatcher.register(
                class_2170.method_9247("showbody")
                        .executes(TestPlayerCommand::showBodyStatus)
        );
    }

    private static int execute(CommandContext<class_2168> context) {
        try {
            class_3222 player = context.getSource().method_9207();

            player.method_43496(class_2561.method_43470("=== Exodus Player Test ==="));
            player.method_43496(class_2561.method_43470("Доступные команды:"));
            player.method_43496(class_2561.method_43470("/damageleg - Повредить левую ногу (-30 HP)"));
            player.method_43496(class_2561.method_43470("/healleg - Вылечить левую ногу (+50 HP)"));
            player.method_43496(class_2561.method_43470("/showbody - Показать состояние всех частей тела"));

            return 1;
        } catch (Exception e) {
            context.getSource().method_9213(class_2561.method_43470("Ошибка: " + e.getMessage()));
            return 0;
        }
    }

    private static int damageLeg(CommandContext<class_2168> context) {
        try {
            class_3222 player = context.getSource().method_9207();

            // Наносим урон левой ноге
            ExodusCoreAPI.damageBodyPart(player, BodyPart.LEFT_LEG, 30f);

            // Получаем текущее состояние
            float legHP = ExodusCoreAPI.getBodyPart(player, BodyPart.LEFT_LEG).currentHP;
            float legMaxHP = ExodusCoreAPI.getBodyPart(player, BodyPart.LEFT_LEG).maxHP;
            boolean isBroken = ExodusCoreAPI.getBodyPart(player, BodyPart.LEFT_LEG).isBroken;

            player.method_43496(class_2561.method_43470("Нанесено 30 урона левой ноге!"));
            player.method_43496(class_2561.method_43470("Левая нога: " + legHP + "/" + legMaxHP + " HP"));
            if (isBroken) {
                player.method_43496(class_2561.method_43470("⚠ НОГА СЛОМАНА!"));
            }

            float totalHP = ExodusCoreAPI.getTotalHP(player);
            player.method_43496(class_2561.method_43470("Общее HP: " + totalHP));

            return 1;
        } catch (Exception e) {
            context.getSource().method_9213(class_2561.method_43470("Ошибка: " + e.getMessage()));
            return 0;
        }
    }

    private static int healLeg(CommandContext<class_2168> context) {
        try {
            class_3222 player = context.getSource().method_9207();

            // Лечим левую ногу
            ExodusCoreAPI.healBodyPart(player, BodyPart.LEFT_LEG, 50f);

            // Получаем текущее состояние
            float legHP = ExodusCoreAPI.getBodyPart(player, BodyPart.LEFT_LEG).currentHP;
            float legMaxHP = ExodusCoreAPI.getBodyPart(player, BodyPart.LEFT_LEG).maxHP;
            boolean isBroken = ExodusCoreAPI.getBodyPart(player, BodyPart.LEFT_LEG).isBroken;

            player.method_43496(class_2561.method_43470("Восстановлено 50 HP левой ноги!"));
            player.method_43496(class_2561.method_43470("Левая нога: " + legHP + "/" + legMaxHP + " HP"));
            if (!isBroken) {
                player.method_43496(class_2561.method_43470("✓ Нога восстановлена!"));
            }

            float totalHP = ExodusCoreAPI.getTotalHP(player);
            player.method_43496(class_2561.method_43470("Общее HP: " + totalHP));

            return 1;
        } catch (Exception e) {
            context.getSource().method_9213(class_2561.method_43470("Ошибка: " + e.getMessage()));
            return 0;
        }
    }

    private static int showBodyStatus(CommandContext<class_2168> context) {
        try {
            class_3222 player = context.getSource().method_9207();

            player.method_43496(class_2561.method_43470("=== Состояние частей тела ==="));

            // Показываем все части тела
            for (BodyPart part : BodyPart.values()) {
                float hp = ExodusCoreAPI.getBodyPart(player, part).currentHP;
                float maxHP = ExodusCoreAPI.getBodyPart(player, part).maxHP;
                boolean isBroken = ExodusCoreAPI.getBodyPart(player, part).isBroken;

                String status = isBroken ? " [СЛОМАНА]" : "";
                player.method_43496(class_2561.method_43470(
                        part.getDisplayName() + ": " +
                                String.format("%.1f", hp) + "/" +
                                String.format("%.1f", maxHP) + " HP" +
                                status
                ));
            }

            player.method_43496(class_2561.method_43470("---"));
            player.method_43496(class_2561.method_43470("Всего HP: " +
                    String.format("%.1f", ExodusCoreAPI.getTotalHP(player)) + "/" +
                    String.format("%.1f", ExodusCoreAPI.getTotalMaxHP(player))
            ));

            return 1;
        } catch (Exception e) {
            context.getSource().method_9213(class_2561.method_43470("Ошибка: " + e.getMessage()));
            return 0;
        }
    }
}