package com.exodus.core;

import com.exodus.core.api.player.BodyPart;
import com.exodus.core.api.player.ExodusPlayerData;
import com.exodus.core.api.stats.*;
import com.exodus.core.player.ExodusPlayerComponent;
import com.exodus.core.player.ExodusPlayerManager;
import com.exodus.core.stats.AttributeEffects;
import com.exodus.core.stats.PlayerStatsComponent;
import com.exodus.core.stats.PlayerStatsManager;
import com.exodus.core.stats.StatsProvider;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_1657;

/**
 * Главный API класс для Exodus Core
 * Другие моды используют этот класс для взаимодействия с системой статов
 */
public class ExodusCoreAPI {

    private static final IStatsProvider statsProvider = new StatsProvider();

    // ==================== ПРОВАЙДЕР ====================

    /**
     * Получить провайдер статов
     * Используется HUD для отображения
     */
    public static IStatsProvider getStatsProvider() {
        return statsProvider;
    }

    /**
     * Получить компонент статов игрока
     * Используется другими модами для изменения статов
     */
    public static PlayerStatsComponent getPlayerStats(class_1657 player) {
        return PlayerStatsManager.getStats(player);
    }

    // ==================== АТРИБУТЫ ====================

    /**
     * Получить уровень атрибута игрока
     */
    public static int getAttribute(class_1657 player, AttributeType type) {
        return getPlayerStats(player).getAttribute(type);
    }

    /**
     * Установить уровень атрибута
     */
    public static void setAttribute(class_1657 player, AttributeType type, int level) {
        getPlayerStats(player).setAttribute(type, level);
    }

    /**
     * Увеличить атрибут на 1 уровень
     */
    public static void increaseAttribute(class_1657 player, AttributeType type) {
        getPlayerStats(player).increaseAttribute(type);
    }

    /**
     * Получить все атрибуты игрока
     */
    public static Map<AttributeType, Integer> getAttributes(class_1657 player) {
        return getPlayerStats(player).getAttributes();
    }

    // ==================== ПОКАЗАТЕЛИ ====================

    /**
     * Получить или создать конкретный показатель
     * @param player игрок
     * @param type тип показателя
     */
    public static IPlayerStat getOrCreateVital(class_1657 player, VitalType type) {
        return getPlayerStats(player).getOrCreateVital(type);
    }

    /**
     * Получить показатель если он существует
     * @param player игрок
     * @param type тип показателя
     */
    public static Optional<IPlayerStat> getVital(class_1657 player, VitalType type) {
        return statsProvider.getVital(player, type);
    }

    /**
     * Проверить есть ли показатель у игрока
     */
    public static boolean hasVital(class_1657 player, VitalType type) {
        return statsProvider.hasVital(player, type);
    }

    // ==================== РАСЧЕТЫ ====================

    /**
     * Рассчитать максимальное значение показателя с учетом атрибутов
     */
    public static float calculateMaxVital(class_1657 player, VitalType type) {
        Map<AttributeType, Integer> attributes = getAttributes(player);
        return AttributeEffects.calculateMaxVital(type, attributes);
    }

    /**
     * Рассчитать модификатор скорости уменьшения показателя
     */
    public static float calculateDecayModifier(class_1657 player, VitalType type) {
        Map<AttributeType, Integer> attributes = getAttributes(player);
        return AttributeEffects.calculateDecayModifier(type, attributes);
    }

    /**
     * Рассчитать бонус к скорости передвижения
     */
    public static float calculateMovementSpeed(class_1657 player) {
        Map<AttributeType, Integer> attributes = getAttributes(player);
        return AttributeEffects.calculateMovementSpeed(attributes);
    }

    /**
     * Рассчитать бонус к урону
     */
    public static float calculateDamageBonus(class_1657 player) {
        Map<AttributeType, Integer> attributes = getAttributes(player);
        return AttributeEffects.calculateDamageBonus(attributes);
    }

    /**
     * Рассчитать шанс критического урона
     */
    public static float calculateCritChance(class_1657 player) {
        Map<AttributeType, Integer> attributes = getAttributes(player);
        return AttributeEffects.calculateCritChance(attributes);
    }

    /**
     * Рассчитать максимальную грузоподъемность
     */
    public static float calculateMaxCarryWeight(class_1657 player) {
        Map<AttributeType, Integer> attributes = getAttributes(player);
        return AttributeEffects.calculateMaxCarryWeight(attributes);
    }

    /**
     * Рассчитать бонус к качеству крафта
     */
    public static float calculateCraftQuality(class_1657 player) {
        Map<AttributeType, Integer> attributes = getAttributes(player);
        return AttributeEffects.calculateCraftQuality(attributes);
    }

    /**
     * Рассчитать сопротивление стрессу
     */
    public static float calculateStressResistance(class_1657 player) {
        Map<AttributeType, Integer> attributes = getAttributes(player);
        return AttributeEffects.calculateStressResistance(attributes);
    }

    // ==================== ОБРАТНАЯ СОВМЕСТИМОСТЬ ====================
    // Старые методы для StatType - помечены как @Deprecated

    /**
     * @deprecated Используйте getOrCreateVital(Player, VitalType)
     */
    @Deprecated
    public static IPlayerStat getOrCreateStat(class_1657 player, StatType type, float defaultMax) {
        VitalType vitalType = convertStatTypeToVitalType(type);
        if (vitalType != null) {
            return getOrCreateVital(player, vitalType);
        }
        throw new IllegalArgumentException("Неизвестный тип стата: " + type);
    }

    /**
     * @deprecated Используйте getVital(Player, VitalType)
     */
    @Deprecated
    public static Optional<IPlayerStat> getStat(class_1657 player, StatType type) {
        VitalType vitalType = convertStatTypeToVitalType(type);
        if (vitalType != null) {
            return getVital(player, vitalType);
        }
        return Optional.empty();
    }

    /**
     * @deprecated Используйте hasVital(Player, VitalType)
     */
    @Deprecated
    public static boolean hasStat(class_1657 player, StatType type) {
        VitalType vitalType = convertStatTypeToVitalType(type);
        if (vitalType != null) {
            return hasVital(player, vitalType);
        }
        return false;
    }

    /**
     * Конвертировать старый StatType в новый VitalType
     */
    private static VitalType convertStatTypeToVitalType(StatType type) {
        return switch (type) {
            case HEALTH -> VitalType.HEALTH;
            case OXYGEN -> VitalType.OXYGEN;
            case THIRST -> VitalType.THIRST;
            case HUNGER -> VitalType.HUNGER;
            case STAMINA -> VitalType.ENERGY;
            default -> null;
        };
    }
    // ==================== ИГРОК ====================

    /**
     * Получить компонент расширенных данных игрока
     */
    public static ExodusPlayerComponent getPlayerComponent(class_1657 player) {
        return ExodusPlayerManager.getComponent(player);
    }

    /**
     * Получить данные игрока
     */
    public static ExodusPlayerData getPlayerData(class_1657 player) {
        return getPlayerComponent(player).getData();
    }

    // ==================== ЧАСТИ ТЕЛА ====================

    /**
     * Получить данные части тела
     */
    public static ExodusPlayerData.BodyPartData getBodyPart(class_1657 player, BodyPart part) {
        return getPlayerComponent(player).getBodyPart(part);
    }

    /**
     * Нанести урон части тела
     */
    public static void damageBodyPart(class_1657 player, BodyPart part, float damage) {
        getPlayerComponent(player).damageBodyPart(part, damage);
    }

    /**
     * Вылечить часть тела
     */
    public static void healBodyPart(class_1657 player, BodyPart part, float amount) {
        getPlayerComponent(player).healBodyPart(part, amount);
    }

    /**
     * Получить суммарное HP всех частей тела
     */
    public static float getTotalHP(class_1657 player) {
        return getPlayerData(player).getTotalHP();
    }

    /**
     * Получить суммарное максимальное HP
     */
    public static float getTotalMaxHP(class_1657 player) {
        return getPlayerData(player).getTotalMaxHP();
    }

    // ==================== ФИЗИОЛОГИЯ ====================

    /**
     * Получить уровень крови (0-100%)
     */
    public static float getBloodLevel(class_1657 player) {
        return getPlayerData(player).getBloodLevel();
    }

    /**
     * Установить уровень крови
     */
    public static void setBloodLevel(class_1657 player, float level) {
        getPlayerData(player).setBloodLevel(level);
    }

    /**
     * Потерять кровь
     */
    public static void loseBlood(class_1657 player, float amount) {
        getPlayerData(player).loseBlood(amount);
    }

    /**
     * Восстановить кровь
     */
    public static void restoreBlood(class_1657 player, float amount) {
        getPlayerData(player).restoreBlood(amount);
    }

    /**
     * Получить температуру тела
     */
    public static float getBodyTemperature(class_1657 player) {
        return getPlayerData(player).getBodyTemperature();
    }

    /**
     * Установить температуру тела
     */
    public static void setBodyTemperature(class_1657 player, float temp) {
        getPlayerData(player).setBodyTemperature(temp);
    }
}