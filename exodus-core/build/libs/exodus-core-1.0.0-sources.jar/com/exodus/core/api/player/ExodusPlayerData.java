package com.exodus.core.api.player;

import java.util.EnumMap;
import java.util.Map;
import net.minecraft.class_2487;

/**
 * Расширенные данные игрока Project Exodus
 * Содержит всю дополнительную информацию о персонаже
 */
public class ExodusPlayerData {

    // ============ БАЗОВАЯ ИНФОРМАЦИЯ ============
    private String characterName;
    private int level;
    private int experience;

    // ============ ЧАСТИ ТЕЛА ============
    private Map<BodyPart, BodyPartData> bodyParts;

    // ============ ФИЗИОЛОГИЯ ============
    private float bloodLevel = 100f;              // Уровень крови (0-100%)
    private float bodyTemperature = 36.6f;        // Температура тела (°C)
    private long lastCriticalHPCheck = 0;         // Время последней проверки критического HP
    private long starvationStartTime = 0;         // Когда начался голод=0
    private long dehydrationStartTime = 0;        // Когда началась жажда=0

    /**
     * Данные одной части тела
     */
    public static class BodyPartData {
        public float currentHP;
        public float maxHP;
        public boolean isBroken;
        public boolean isBleeding;

        public BodyPartData(float maxHP) {
            this.maxHP = maxHP;
            this.currentHP = maxHP;
            this.isBroken = false;
            this.isBleeding = false;
        }

        /**
         * Получить процент HP (0.0 - 1.0)
         */
        public float getPercentage() {
            if (maxHP <= 0) {
                return 0f;
            }
            return Math.max(0f, Math.min(1f, currentHP / maxHP));
        }

        /**
         * Сохранить в NBT
         */
        public class_2487 writeNbt(class_2487 nbt) {
            nbt.method_10548("currentHP", currentHP);
            nbt.method_10548("maxHP", maxHP);
            nbt.method_10556("isBroken", isBroken);
            nbt.method_10556("isBleeding", isBleeding);
            return nbt;
        }

        /**
         * Загрузить из NBT
         */
        public void readNbt(class_2487 nbt) {
            this.currentHP = nbt.method_10583("currentHP");
            this.maxHP = nbt.method_10583("maxHP");
            this.isBroken = nbt.method_10577("isBroken");
            this.isBleeding = nbt.method_10577("isBleeding");
        }
    }

    public ExodusPlayerData() {
        this.characterName = "";
        this.level = 1;
        this.experience = 0;
        this.bodyParts = new EnumMap<>(BodyPart.class);

        // Инициализируем все части тела
        for (BodyPart part : BodyPart.values()) {
            bodyParts.put(part, new BodyPartData(part.getBaseMaxHP()));
        }
    }

    // ============ ГЕТТЕРЫ/СЕТТЕРЫ: ФИЗИОЛОГИЯ ============

    public float getBloodLevel() {
        return bloodLevel;
    }

    public void setBloodLevel(float level) {
        this.bloodLevel = Math.max(0, Math.min(100, level));
    }

    public void loseBlood(float amount) {
        this.bloodLevel = Math.max(0, bloodLevel - amount);
    }

    public void restoreBlood(float amount) {
        this.bloodLevel = Math.min(100, bloodLevel + amount);
    }

    public float getBodyTemperature() {
        return bodyTemperature;
    }

    public void setBodyTemperature(float temp) {
        this.bodyTemperature = temp;
    }

    public long getLastCriticalHPCheck() {
        return lastCriticalHPCheck;
    }

    public void setLastCriticalHPCheck(long time) {
        this.lastCriticalHPCheck = time;
    }

    public long getStarvationStartTime() {
        return starvationStartTime;
    }

    public void setStarvationStartTime(long time) {
        this.starvationStartTime = time;
    }

    public long getDehydrationStartTime() {
        return dehydrationStartTime;
    }

    public void setDehydrationStartTime(long time) {
        this.dehydrationStartTime = time;
    }

    // ============ ГЕТТЕРЫ/СЕТТЕРЫ: БАЗОВАЯ ИНФОРМАЦИЯ ============

    public String getCharacterName() {
        return characterName;
    }

    public void setCharacterName(String characterName) {
        this.characterName = characterName;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getExperience() {
        return experience;
    }

    public void setExperience(int experience) {
        this.experience = experience;
    }

    // ============ ГЕТТЕРЫ/СЕТТЕРЫ: ЧАСТИ ТЕЛА ============

    public BodyPartData getBodyPart(BodyPart part) {
        return bodyParts.get(part);
    }

    public Map<BodyPart, BodyPartData> getAllBodyParts() {
        return bodyParts;
    }

    /**
     * Получить суммарное HP всех частей тела
     */
    public float getTotalHP() {
        float total = 0;
        for (BodyPartData data : bodyParts.values()) {
            total += data.currentHP;
        }
        return total;
    }

    /**
     * Получить суммарное максимальное HP
     */
    public float getTotalMaxHP() {
        float total = 0;
        for (BodyPartData data : bodyParts.values()) {
            total += data.maxHP;
        }
        return total;
    }

    // ============ NBT СОХРАНЕНИЕ/ЗАГРУЗКА ============

    public class_2487 writeNbt(class_2487 nbt) {
        // Сохраняем базовую информацию
        nbt.method_10582("characterName", characterName);
        nbt.method_10569("level", level);
        nbt.method_10569("experience", experience);

        // Сохраняем части тела
        class_2487 partsNbt = new class_2487();
        for (Map.Entry<BodyPart, BodyPartData> entry : bodyParts.entrySet()) {
            class_2487 partNbt = entry.getValue().writeNbt(new class_2487());
            partsNbt.method_10566(entry.getKey().name(), partNbt);
        }
        nbt.method_10566("bodyParts", partsNbt);

        // Сохраняем физиологию
        nbt.method_10548("bloodLevel", bloodLevel);
        nbt.method_10548("bodyTemperature", bodyTemperature);
        nbt.method_10544("lastCriticalHPCheck", lastCriticalHPCheck);
        nbt.method_10544("starvationStartTime", starvationStartTime);
        nbt.method_10544("dehydrationStartTime", dehydrationStartTime);

        return nbt;
    }

    public void readNbt(class_2487 nbt) {
        // Загружаем базовую информацию
        if (nbt.method_10545("characterName")) {
            this.characterName = nbt.method_10558("characterName");
        }
        if (nbt.method_10545("level")) {
            this.level = nbt.method_10550("level");
        }
        if (nbt.method_10545("experience")) {
            this.experience = nbt.method_10550("experience");
        }

        // Загружаем части тела
        if (nbt.method_10545("bodyParts")) {
            class_2487 partsNbt = nbt.method_10562("bodyParts");
            for (BodyPart part : BodyPart.values()) {
                if (partsNbt.method_10545(part.name())) {
                    class_2487 partNbt = partsNbt.method_10562(part.name());
                    BodyPartData data = getBodyPart(part);
                    data.readNbt(partNbt);
                }
            }
        }

        // Загружаем физиологию
        if (nbt.method_10545("bloodLevel")) {
            this.bloodLevel = nbt.method_10583("bloodLevel");
        }
        if (nbt.method_10545("bodyTemperature")) {
            this.bodyTemperature = nbt.method_10583("bodyTemperature");
        }
        if (nbt.method_10545("lastCriticalHPCheck")) {
            this.lastCriticalHPCheck = nbt.method_10537("lastCriticalHPCheck");
        }
        if (nbt.method_10545("starvationStartTime")) {
            this.starvationStartTime = nbt.method_10537("starvationStartTime");
        }
        if (nbt.method_10545("dehydrationStartTime")) {
            this.dehydrationStartTime = nbt.method_10537("dehydrationStartTime");
        }
    }
}