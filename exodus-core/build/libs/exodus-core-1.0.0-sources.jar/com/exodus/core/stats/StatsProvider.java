package com.exodus.core.stats;

import com.exodus.core.api.stats.IPlayerStat;
import com.exodus.core.api.stats.IStatsProvider;
import com.exodus.core.api.stats.VitalType;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import net.minecraft.class_1657;

/**
 * Базовая реализация провайдера статов
 * HUD будет использовать этот класс для получения данных
 */
public class StatsProvider implements IStatsProvider {

    @Override
    public List<IPlayerStat> getStats(class_1657 player) {
        PlayerStatsComponent component = PlayerStatsManager.getStats(player);
        return component.getAllVitals()
                .stream()
                .map(vital -> (IPlayerStat) vital)
                .collect(Collectors.toList());
    }

    @Override
    public Optional<IPlayerStat> getVital(class_1657 player, VitalType type) {
        PlayerStatsComponent component = PlayerStatsManager.getStats(player);
        return component.getVital(type).map(vital -> (IPlayerStat) vital);
    }

    @Override
    public boolean hasVital(class_1657 player, VitalType type) {
        PlayerStatsComponent component = PlayerStatsManager.getStats(player);
        return component.hasVital(type);
    }
}