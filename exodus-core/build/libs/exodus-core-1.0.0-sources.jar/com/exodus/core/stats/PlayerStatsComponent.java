package com.exodus.core.stats;

import com.exodus.core.api.stats.AttributeType;
import com.exodus.core.api.stats.IPlayerStat;
import com.exodus.core.api.stats.VitalType;
import java.util.*;
import net.minecraft.class_1657;
import net.minecraft.class_2487;

/**
 * Компонент для хранения ВСЕХ статов игрока:
 * - Атрибуты (прокачиваемые характеристики)
 * - Показатели (ресурсы выживания)
 */
public class PlayerStatsComponent {

    private final class_1657 player;

    // Атрибуты - прокачиваемые характеристики
    private final Map<AttributeType, Integer> attributes = new EnumMap<>(AttributeType.class);

    // Показатели выживания
    private final Map<VitalType, PlayerVital> vitals = new EnumMap<>(VitalType.class);

    public PlayerStatsComponent(class_1657 player) {
        this.player = player;
        // Инициализируем атрибуты начальными значениями
        for (AttributeType type : AttributeType.values()) {
            attributes.put(type, 1); // Все начинаются с уровня 1
        }
    }

    // ==================== АТРИБУТЫ ====================

    /**
     * Получить уровень атрибута
     */
    public int getAttribute(AttributeType type) {
        return attributes.getOrDefault(type, 1);
    }

    /**
     * Установить уровень атрибута
     */
    public void setAttribute(AttributeType type, int level) {
        int oldLevel = attributes.getOrDefault(type, 1);
        attributes.put(type, Math.max(1, level)); // Минимум 1

        // Если атрибут изменился - пересчитываем максимумы показателей
        if (oldLevel != level) {
            recalculateVitalsMax();
        }
    }

    /**
     * Увеличить атрибут на 1
     */
    public void increaseAttribute(AttributeType type) {
        setAttribute(type, getAttribute(type) + 1);
    }

    /**
     * Получить все атрибуты
     */
    public Map<AttributeType, Integer> getAttributes() {
        return new EnumMap<>(attributes);
    }

    // ==================== ПОКАЗАТЕЛИ ====================

    /**
     * Получить показатель
     */
    public Optional<PlayerVital> getVital(VitalType type) {
        return Optional.ofNullable(vitals.get(type));
    }

    /**
     * Получить или создать показатель
     */
    public PlayerVital getOrCreateVital(VitalType type) {
        return vitals.computeIfAbsent(type, t -> {
            // Рассчитываем максимум с учетом атрибутов
            float maxValue = AttributeEffects.calculateMaxVital(t, attributes);
            return new PlayerVital(t, player, maxValue);
        });
    }

    /**
     * Установить показатель
     */
    public void setVital(VitalType type, PlayerVital vital) {
        vitals.put(type, vital);
    }

    /**
     * Получить все показатели
     */
    public Collection<PlayerVital> getAllVitals() {
        return vitals.values();
    }

    /**
     * Проверить есть ли показатель
     */
    public boolean hasVital(VitalType type) {
        return vitals.containsKey(type);
    }

    /**
     * Удалить показатель
     */
    public void removeVital(VitalType type) {
        vitals.remove(type);
    }

    /**
     * Пересчитать максимумы всех показателей на основе текущих атрибутов
     */
    public void recalculateVitalsMax() {
        for (Map.Entry<VitalType, PlayerVital> entry : vitals.entrySet()) {
            VitalType type = entry.getKey();
            PlayerVital vital = entry.getValue();

            float newMax = AttributeEffects.calculateMaxVital(type, attributes);
            vital.setMax(newMax);
        }
    }

    // ==================== NBT ====================

    /**
     * Сохранить в NBT
     */
    public class_2487 writeNbt(class_2487 nbt) {
        // Сохраняем атрибуты
        class_2487 attributesNbt = new class_2487();
        for (Map.Entry<AttributeType, Integer> entry : attributes.entrySet()) {
            attributesNbt.method_10569(entry.getKey().getId(), entry.getValue());
        }
        nbt.method_10566("exodus_attributes", attributesNbt);

        // Сохраняем показатели
        class_2487 vitalsNbt = new class_2487();
        for (Map.Entry<VitalType, PlayerVital> entry : vitals.entrySet()) {
            class_2487 vitalNbt = new class_2487();
            entry.getValue().writeNbt(vitalNbt);
            vitalsNbt.method_10566(entry.getKey().getId(), vitalNbt);
        }
        nbt.method_10566("exodus_vitals", vitalsNbt);

        return nbt;
    }

    /**
     * Загрузить из NBT
     */
    public void readNbt(class_2487 nbt) {
        // Загружаем атрибуты
        if (nbt.method_10545("exodus_attributes")) {
            class_2487 attributesNbt = nbt.method_10562("exodus_attributes");
            for (AttributeType type : AttributeType.values()) {
                if (attributesNbt.method_10545(type.getId())) {
                    attributes.put(type, attributesNbt.method_10550(type.getId()));
                }
            }
        }

        // Загружаем показатели
        if (nbt.method_10545("exodus_vitals")) {
            class_2487 vitalsNbt = nbt.method_10562("exodus_vitals");
            for (String key : vitalsNbt.method_10541()) {
                VitalType type = VitalType.fromId(key);
                if (type != null) {
                    class_2487 vitalNbt = vitalsNbt.method_10562(key);
                    PlayerVital vital = getOrCreateVital(type);
                    vital.readNbt(vitalNbt);
                }
            }
        }

        // Пересчитываем максимумы на основе загруженных атрибутов
        recalculateVitalsMax();
    }
}